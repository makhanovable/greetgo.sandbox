CREATE FUNCTION update_wallet()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
          UPDATE client_account
          SET money = ((SELECT money
                        FROM client_account
                        WHERE client_account.id = new.account) + new.money)
          WHERE client_account.id = new.account;
          RETURN new;
        END;
$$;

