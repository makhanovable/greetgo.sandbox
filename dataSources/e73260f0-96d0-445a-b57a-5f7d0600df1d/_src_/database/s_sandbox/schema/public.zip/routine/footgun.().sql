create function footgun() returns void
LANGUAGE plpgsql
AS $$
DECLARE
  row  record;
BEGIN
  FOR row IN
  SELECT
    table_schema,
    table_name
  FROM
    information_schema.tables
  WHERE
    table_name LIKE ('cia_%')
  LOOP
    EXECUTE 'DROP TABLE ' || quote_ident(row.table_schema) || '.' || quote_ident(row.table_name);
    RAISE INFO 'Dropped table: %', quote_ident(row.table_schema) || '.' || quote_ident(row.table_name);
  END LOOP;
END;
$$;
