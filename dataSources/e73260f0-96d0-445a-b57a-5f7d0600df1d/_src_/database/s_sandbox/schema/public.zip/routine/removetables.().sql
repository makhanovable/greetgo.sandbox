create function removetables() returns void
LANGUAGE plpgsql
AS $$
DECLARE row  record;
BEGIN
  FOR row IN
  SELECT
    table_schema,
    table_name
  FROM
    information_schema.tables
  WHERE
    table_name LIKE ('cia_migration%')
  LOOP
    EXECUTE 'DROP TABLE ' || quote_ident(row.table_schema) || '.' || quote_ident(row.table_name);
  END LOOP;
END;
$$;
