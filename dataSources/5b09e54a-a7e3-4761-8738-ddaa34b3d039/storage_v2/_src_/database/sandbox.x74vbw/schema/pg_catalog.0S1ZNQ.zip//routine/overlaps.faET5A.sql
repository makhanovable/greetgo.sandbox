CREATE FUNCTION "overlaps"(timestamp with time zone, interval, timestamp with time zone, timestamp with time zone)
  RETURNS boolean
STABLE
PARALLEL SAFE
COST 1
LANGUAGE SQL
AS $$
select ($1, ($1 + $2)) overlaps ($3, $4)
$$;

